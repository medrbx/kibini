from KohaBundle import KohaBundle
import pandas as pd

kb = KohaBundle()
bundle_itemnumber = 499679
kb.list_items(bundle_itemnumber)
if kb.nb_items > 0:
    items_df = pd.json_normalize(kb.items_in_bundle)
    items_df['bundle_itemnumber'] = bundle_itemnumber
    items_df = items_df[['bundle_itemnumber', 'item_id', 'external_id']]
    items_df.columns = ['bundle_itemnumber', 'itemnumber', 'barcode']
    print(items_df)
