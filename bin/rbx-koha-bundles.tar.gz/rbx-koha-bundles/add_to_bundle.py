from datetime import datetime
from os.path import join

import pandas as pd

from KohaBundle import KohaBundle

horodatage = datetime.now().strftime("%Y%m%d%H%M%S")

kb = KohaBundle()

exemplaires = pd.read_csv(join("data", "ex2bundles.csv"))
i = 0
n = len(exemplaires)
for ex in exemplaires.to_dict(orient="records"):
    kb.add_to_bundle(ex["bundle_itemnumber"], ex["itemnumber"], ex["barcode"])
    i += 1
    print(f"{i} / {n}")
res = pd.DataFrame(kb.logs)
res.to_csv(join("log", "log_{horodatage}.csv"), index=False)
