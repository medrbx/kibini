from KohaBundle import KohaBundle
from os.path import join
import pandas as pd

kb = KohaBundle()

exemplaires = pd.read_csv(join("data", "ex2bundles_MA066.csv"))
for ex in exemplaires.to_dict(orient='records'):
    kb.remove_from_bundle(ex['bundle_itemnumber'], ex['itemnumber'], ex['barcode'])
res = pd.DataFrame(kb.logs)
print(res)
