from os.path import join

import pandas as pd

a = pd.read_csv(join("data", "288-malles-reportresults.csv"), sep=";")
b = pd.read_csv(
    join("data", "289-malles - liste notices bundle-reportresults.csv"), sep=";"
)

z = a.merge(b, on="code_malle", how="inner")
z.to_csv(join("data", "ex2bundles.csv"), index=False)
# z[z['code_malle'] == 'K001'].to_csv(join("data", "ex2bundles_K001.csv"), index=False)
# z[z['code_malle'] == 'MA066'].to_csv(join("data", "ex2bundles_MA066.csv"), index=False)
# z[z['code_malle'] != 'MA066'].to_csv(join("data", "ex2bundles_noMA066.csv"), index=False)
