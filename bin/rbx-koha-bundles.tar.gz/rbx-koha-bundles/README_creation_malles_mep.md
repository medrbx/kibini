# Création des malles lors de la mise en prod Koha 24.11

## Etape 1 : import des notices de malle
On utilise l'outil "Catalogage > Télécharger des notices dans le réservoir" pour import un fichier marc comprenant l'ensemble des notices de malle.

Le fichier est déposé ici : data\notices_mep\malles_20260307.xml

Points de vigilance :
- c'est du marcxml, bien modifier le format,
- bien ajouter les exemplaires
- choisir la grille de catalogage "Malles"

## Etape 2 : on lie les exemplaires composant la malle aux paquets des notices de malle

1. On commence par exécuter deux rapports dans Koha :
- le rapport 288 (liste des exemplaires malles) : à enregistrer sous le nom "data/288-malles-reportresults.csv" (séparateur : ";")
- le rapport 289 (liste des paquets) : à enregistrer sous le nom "data/289-malles - liste notices bundle-reportresults.csv" (séparateur : ";")

2. On fusionne les données des deux rapports en exécutant fusion_rapports_malles.py

3. On lance le script add_to_bundle.py
Attention script long et un peu gourmand en ressources : le lancer quand l'activité est calme

4. On obtient un fichier de résultats dans le répertoire log, pour faire des vérifications
