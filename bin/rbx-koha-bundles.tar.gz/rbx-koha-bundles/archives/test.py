from requests.auth import HTTPBasicAuth
import pandas as pd
import requests
import json
import datetime

import warnings
warnings.filterwarnings("ignore")

ws_conf = {
    'base': 'https://cataloguekoha-new.ntrbx.local',
    'user': 'webservice_user',
    'pwd': 'La*GrandPlage1979'
}
basic_auth = HTTPBasicAuth(ws_conf['user'], ws_conf['pwd'])

item_id = 264448
bundle_item_id = 499614
item_id = 499614
bundle_item_id = 264448

url = f"{ws_conf['base']}/api/v1/items/{item_id}/bundled_items/{bundle_item_id}"
response = requests.delete(url, auth=basic_auth, verify=False)
print(response)
