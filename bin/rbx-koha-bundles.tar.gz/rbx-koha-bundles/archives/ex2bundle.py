from requests.auth import HTTPBasicAuth
import pandas as pd
import requests
import json
import datetime

import warnings
warnings.filterwarnings("ignore")

ws_conf = {
    'base': 'https://cataloguekoha-new.ntrbx.local',
    'user': 'webservice_user',
    'pwd': 'La*GrandPlage1979'
}
basic_auth = HTTPBasicAuth(ws_conf['user'], ws_conf['pwd'])


exemplaires = pd.read_csv("ex2bundles_noMA066.csv")
for ex in exemplaires.to_dict(orient='records'):
    try:
        bundle_item_id = ex['bundle_itemnumber']
        url = f"{ws_conf['base']}/api/v1/items/{bundle_item_id}/bundled_items"
        data = json.dumps(
            {
              "item_id": ex['itemnumber'],
              "external_id": ex['barcode'],
              "force_checkin": True,
              "ignore_holds": True,
              "marc_link": True
            }
        )
        response = requests.post(url, auth=basic_auth, verify=False, data=data)
        print(f"ok pour exemplaire {ex['barcode']}")

    except:
        print(f"ko pour exemplaire {ex['barcode']}")
