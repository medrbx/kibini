from yaml import safe_load
import os.path
from requests.auth import HTTPBasicAuth
import pandas as pd
import requests
import json

import warnings
warnings.filterwarnings("ignore")

class Config():
    def __init__(self):
        my_path = os.path.abspath(os.path.dirname(__file__))
        config_file_path = os.path.join(my_path, 'conf/koha_api.yml')
        with open(config_file_path, 'r') as stream:
            try:
                self.dataconfig = safe_load(stream)
            except yaml.YAMLError as exc:
                print(exc)

    def get_config_koha_rest(self):
        return self.dataconfig['koha_rest']

class KohaBundle:
    def __init__(self):
        conf = Config().get_config_koha_rest()
        self.base = conf['base']
        self.basic_auth = HTTPBasicAuth(conf['user'], conf['pwd'])
        self.logs = []

    def list_items(self, bundle_item_id):
        url = f"{self.base}/api/v1/items/{bundle_item_id}/bundled_items"
        print(url)
        response = requests.get(url, auth=self.basic_auth, verify=False)
        self.nb_items = 0
        if response.status_code == 200:
            self.items_in_bundle = response.json()
            self.nb_items = len(self.items_in_bundle)


    def add_to_bundle(self, bundle_item_id, itemnumber, barcode):
        url = f"{self.base}/api/v1/items/{bundle_item_id}/bundled_items"
        data = json.dumps(
            {
              "item_id": itemnumber,
              "external_id": barcode,
              "force_checkin": True,
              "ignore_holds": True,
              "marc_link": True
            }
        )
        response = requests.post(url, auth=self.basic_auth, verify=False, data=data)
        log = {"action": "ajout", "bundle_item_id": bundle_item_id, "itemnumber":itemnumber, "barcode":barcode}
        if response.status_code == 201:
            log['resultat'] = 'ok'
        else:
            log['resultat'] = 'ko'
        self.logs.append(log)

    def remove_from_bundle(self, bundle_item_id, item_id, barcode):
        url = f"{self.base}/api/v1/items/{bundle_item_id}/bundled_items/{item_id}"
        response = requests.delete(url, auth=self.basic_auth, verify=False)
        log = {"action": "suppression", "bundle_item_id": bundle_item_id, "itemnumber":item_id, "barcode": barcode}
        if response.status_code == 204:
            log['resultat'] = 'ok'
        else:
            log['resultat'] = response.status_code
        self.logs.append(log)
